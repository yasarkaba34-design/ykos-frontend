import React, { useState, useEffect } from 'react';
import { db } from "../data/firebase";
import { collection, doc, setDoc, serverTimestamp } from "firebase/firestore";

export default function YoneticiIcerikGirisi({ secilenVeri, onKayitTamamlandi }) {
  const [kaydediliyor, setKaydediliyor] = useState(false);
  // 5 Temel İçerik / Kategori Türü
  const icerikTurleri = [
    "Araştırma yazısı",
    "Makale",
    "Arkeolojik bulgu",
    "Kök-hece incelemesi",
    "Damga/sembol araştırması"
  ];

  const [formData, setFormData] = useState({
    icerikTuru: "Araştırma yazısı",
    baslik: "",
    ulke: "Türkiye",
    ilceKoyMevki: "",
    arkeolojikAlan: "",
    koordinatlar: "",
    kaynakLink: "",
    fotografci: "",
    ykosKokHeceKodu: "",
    telifIzni: "Açık Kaynak (Serbest)",
    kapakGorseli: null,
    galeriGorselleri: [],
    videoUrl: "", // 🎥 Yeni: Video Bağlantı Alanı
    kisaOzet: "",
    kapsamliAnaliz: "",
    durum: "onaylandi", // Yönetici doğrudan girerse onaylı
    yazar: "Yaşar Kaba (Admin)"
  });

  // Havuzdan "İncele/Düzenle" dendiğinde formu doldur
  useEffect(() => {
    if (secilenVeri) {
      setFormData(prev => ({
        ...prev,
        ...secilenVeri,
        videoUrl: secilenVeri.videoUrl || "",
        durum: "onaylandi"
      }));
    }
  }, [secilenVeri]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGorselYukle = (e, tip) => {
    const files = e.target.files;
    if (tip === "kapak" && files[0]) {
      setFormData(prev => ({ ...prev, kapakGorseli: URL.createObjectURL(files[0]) }));
    } else if (tip === "galeri") {
      const gorselDizisi = Array.from(files).map(f => URL.createObjectURL(f));
      setFormData(prev => ({ ...prev, galeriGorselleri: [...prev.galeriGorselleri, ...gorselDizisi] }));
    }
  };

 const handleSubmit = async (e) => {
  e.preventDefault();

  if (kaydediliyor) return;

  if (!formData.baslik.trim()) {
    alert("Lütfen içerik başlığını giriniz!");
    return;
  }

  // Geçici görsel adresleri diğer cihazlarda çalışmaz.
  const gorseller = [
    formData.kapakGorseli,
    ...(formData.galeriGorselleri || [])
  ];

  if (gorseller.some(
    (adres) => typeof adres === "string" && adres.startsWith("blob:")
  )) {
    alert(
      "Görseller geçici tarayıcı adresi kullanıyor. " +
      "Önce kalıcı görsel yükleme bağlantısını düzenlemeliyiz."
    );
    return;
  }

  setKaydediliyor(true);

  try {
    // Yeni kayıtta kimlik üret; düzenlemede aynı belgeyi güncelle.
    const mevcutId = formData.id || secilenVeri?.id;
    const belge = mevcutId
      ? doc(db, "bulgular", String(mevcutId))
      : doc(collection(db, "bulgular"));

    const kayit = {
      ...formData,
      id: belge.id,
      baslik: formData.baslik.trim(),
      durum: "onaylandi",
      status: "approved",
      guncellenmeTarihi: serverTimestamp()
    };

    // Firestore undefined değerleri kabul etmez.
    Object.keys(kayit).forEach((alan) => {
      if (kayit[alan] === undefined) delete kayit[alan];
    });

    await setDoc(belge, kayit, { merge: true });

    setFormData((prev) => ({
      ...prev,
      id: belge.id,
      durum: "onaylandi",
      status: "approved"
    }));

    alert("✓ İçerik Firebase veritabanına kaydedildi.");

    if (onKayitTamamlandi) onKayitTamamlandi();
  } catch (error) {
    console.error("Firebase kayıt hatası:", error);
    alert(
      "Kayıt tamamlanamadı. Formdaki bilgiler korunuyor.\n" +
      (error.code || error.message)
    );
  } finally {
    setKaydediliyor(false);
  }
};

  return (
    <form onSubmit={handleSubmit} style={formStyle.container}>
      
      {/* 1. İÇERİK TÜRÜ / KATEGORİ SEÇİMİ */}
      <div style={formStyle.section}>
        <label style={formStyle.label}>İÇERİK TÜRÜ & KATEGORİ</label>
        <select 
          name="icerikTuru" 
          value={formData.icerikTuru} 
          onChange={handleChange} 
          style={formStyle.select}
        >
          {icerikTurleri.map((tur, i) => (
            <option key={i} value={tur}>{tur}</option>
          ))}
        </select>
      </div>

      {/* 2. BAŞLIK */}
      <div style={formStyle.section}>
        <label style={formStyle.label}>BAŞLIK</label>
        <input 
          type="text" 
          name="baslik" 
          placeholder="İçerik, bulgu veya makale başlığı..." 
          value={formData.baslik} 
          onChange={handleChange} 
          style={formStyle.input} 
        />
      </div>

     {/* 🎥 4. VİDEO BAĞLANTISI */}
<div
  style={{
    ...formStyle.section,
    width: "100%",
    minWidth: 0,
    boxSizing: "border-box",
    overflow: "visible"
  }}
>
  <label
    htmlFor="videoUrl"
    style={{
      ...formStyle.label,
      display: "block",
      marginBottom: "7px",
      color: "#38bdf8"
    }}
  >
    🎥 VİDEO BAĞLANTISI (YouTube / Video URL)
  </label>

  <input
    id="videoUrl"
    type="url"
    name="videoUrl"
    placeholder="https://www.youtube.com/watch?v=..."
    value={formData.videoUrl || ""}
    onChange={handleChange}
    inputMode="url"
    autoComplete="off"
    style={{
      ...formStyle.input,
      display: "block",
      width: "100%",
      minWidth: 0,
      maxWidth: "100%",
      boxSizing: "border-box",
      borderColor: "#38bdf8"
    }}
  />

  {formData.videoUrl && (
    <div
      style={{
        marginTop: "7px",
        color: "#94a3b8",
        fontSize: "0.78rem",
        overflowWrap: "anywhere"
      }}
    >
      Eklenen bağlantı: {formData.videoUrl}
    </div>
  )}
</div>
      {/* 6. METİN VE ANALİZ ALANLARI */}
      <div style={formStyle.section}>
        <label style={formStyle.label}>Kısa Özet</label>
        <textarea 
          name="kisaOzet" 
          rows="3" 
          placeholder="Bulgunun veya araştırmanın kısa özeti..." 
          value={formData.kisaOzet} 
          onChange={handleChange} 
          style={formStyle.textarea} 
        />
      </div>

      <div style={formStyle.section}>
        <label style={formStyle.label}>Kapsamlı Analiz / Makale İçeriği</label>
        <textarea 
          name="kapsamliAnaliz" 
          rows="8" 
          placeholder="Bulgunun arkeolojik, etimolojik ve kök-hece çözümleme metni..." 
          value={formData.kapsamliAnaliz} 
          onChange={handleChange} 
          style={formStyle.textarea} 
        />
      </div>

      {/* GÖNDER BUTONU */}
      <button type="submit" style={formStyle.submitBtn}>
        🚀 AKADEMİK VERİYİ VE VİDEOYU VERİTABANINA GÖNDER
      </button>

    </form>
  );
}

const formStyle = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
    background: '#050608',
    padding: '24px',
    borderRadius: '10px',
    border: '1px solid #26262a',
    color: '#fff'
  },
  section: { display: 'flex', flexDirection: 'column', gap: '6px' },
  grid2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' },
  label: { fontSize: '11px', color: '#a0a0a0', fontWeight: 'bold', letterSpacing: '0.05em', textTransform: 'uppercase' },
  input: { padding: '12px', background: '#0b0c10', border: '1px solid #2a2a2a', color: '#fff', borderRadius: '6px', fontSize: '13px', outline: 'none' },
  select: { padding: '12px', background: '#0b0c10', border: '1px solid #ffd700', color: '#ffd700', borderRadius: '6px', fontSize: '13px', fontWeight: 'bold', outline: 'none' },
  textarea: { padding: '12px', background: '#0b0c10', border: '1px solid #2a2a2a', color: '#fff', borderRadius: '6px', fontSize: '13px', outline: 'none', resize: 'vertical' },
  fileInput: { padding: '8px', background: '#0b0c10', border: '1px dashed #ffd700', borderRadius: '6px', color: '#a0a0a0', fontSize: '12px' },
  previewImg: { width: '120px', height: '80px', objectFit: 'cover', borderRadius: '6px', marginTop: '8px', border: '1px solid #ffd700' },
  submitBtn: { padding: '16px', background: '#ffd700', color: '#000', border: 'none', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', cursor: 'pointer', marginTop: '10px' }
};
